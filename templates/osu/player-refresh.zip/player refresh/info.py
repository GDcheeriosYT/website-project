osu_path = "" #Put path to osu folder inbetween quotes like C:users/user/appdata/local/osu! no backslashes make sure /
osu_username = "" #Put your osu username case sensitive in the quotes
